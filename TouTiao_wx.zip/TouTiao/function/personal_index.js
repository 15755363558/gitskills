function set_title(){
    wx.setNavigationBarTitle({
        title: '餐饮咖 « 我'
    });
}

module.exports = {
    set_title: set_title,
}
