function set_title(){
    wx.setNavigationBarTitle({
        title: '餐饮咖 « 发现'
    });
}

module.exports = {
    set_title: set_title,
}

