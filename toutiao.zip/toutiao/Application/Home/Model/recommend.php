<?php
  
  $article=M('article');   //大M方法访问数据表
  $sql=$article->select();  //thinkPHP 封装的SQL查询所有数据
  var_dump($sql);     //打印出数据
  echo "123";
